<?php
require_once '../includes/db.php';

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$code = $input['code'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM promos WHERE code = ? AND status = 'active'");
$stmt->execute([$code]);
$promo = $stmt->fetch(PDO::FETCH_ASSOC);

if ($promo) {
    echo json_encode([
        'valid' => true,
        'discount_percent' => $promo['discount_percent'],
        'code' => $promo['code']
    ]);
} else {
    echo json_encode(['valid' => false]);
}
?>
