<?php
require_once 'includes/db.php';
require_once 'includes/payment-functions.php';

$orderId = $_GET['order_id'] ?? 0;
$paymentMethod = $_GET['method'] ?? '';

// Get order details
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: index.php');
    exit();
}

$message = '';
$error = '';

// Handle payment verification
if ($_POST) {
    if ($paymentMethod === 'esewa' && isset($_POST['refId'])) {
        $refId = $_POST['refId'];
        if (verifyEsewaPayment($refId, $order['final_amount'])) {
            $stmt = $pdo->prepare("UPDATE orders SET payment_status = 'completed', payment_reference = ? WHERE id = ?");
            $stmt->execute([$refId, $orderId]);
            $message = 'Payment verified successfully!';
        } else {
            $error = 'Payment verification failed';
        }
    } elseif ($paymentMethod === 'khalti' && isset($_POST['token'])) {
        $token = $_POST['token'];
        if (verifyKhaltiPayment($token, $order['final_amount'])) {
            $stmt = $pdo->prepare("UPDATE orders SET payment_status = 'completed', payment_reference = ? WHERE id = ?");
            $stmt->execute([$token, $orderId]);
            $message = 'Payment verified successfully!';
        } else {
            $error = 'Payment verification failed';
        }
    } elseif ($paymentMethod === 'bank' && isset($_FILES['receipt'])) {
        $receiptName = uploadFile($_FILES['receipt'], 'uploads/receipts', ['jpg', 'jpeg', 'png'], 2 * 1024 * 1024);
        if ($receiptName) {
            $stmt = $pdo->prepare("UPDATE orders SET payment_reference = ? WHERE id = ?");
            $stmt->execute([$receiptName, $orderId]);
            $message = 'Payment receipt uploaded successfully! Your order is being processed.';
        } else {
            $error = 'Invalid receipt file. Only JPG, PNG allowed (max 2MB)';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - E-commerce Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <?php if ($paymentMethod === 'khalti'): ?>
    <script src="https://khalti.s3.ap-south-1.amazonaws.com/KPG/dist/2020.12.17.0.0.0/khalti-checkout.iffe.js"></script>
    <?php endif; ?>
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <i class="fas fa-store text-2xl text-blue-500 mr-3"></i>
                    <h1 class="text-2xl font-bold text-gray-800">E-commerce Store</h1>
                </div>
            </div>
        </div>
    </header>
    
    <!-- Payment Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <div class="max-w-2xl mx-auto">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-2xl font-bold mb-6 text-center">
                        <i class="fas fa-credit-card mr-2"></i>Payment
                    </h2>
                    
                    <?php if ($message): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                            <?php echo $message; ?>
                            <div class="mt-4">
                                <a href="index.php" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                    Continue Shopping
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-6 p-4 bg-gray-50 rounded-lg">
                        <h3 class="font-semibold mb-2">Order Details</h3>
                        <p><strong>Order ID:</strong> #<?php echo $order['id']; ?></p>
                        <p><strong>Amount:</strong> रु <?php echo number_format($order['final_amount'], 2); ?></p>
                        <p><strong>Payment Method:</strong> <?php echo ucfirst($paymentMethod); ?></p>
                    </div>
                    
                    <?php if ($paymentMethod === 'esewa'): ?>
                        <div class="text-center">
                            <p class="mb-4">You will be redirected to eSewa for payment.</p>
                            <form action="https://uat.esewa.com.np/epay/main" method="POST">
                                <input type="hidden" name="tAmt" value="<?php echo $order['final_amount']; ?>">
                                <input type="hidden" name="amt" value="<?php echo $order['final_amount']; ?>">
                                <input type="hidden" name="txAmt" value="0">
                                <input type="hidden" name="psc" value="0">
                                <input type="hidden" name="pdc" value="0">
                                <input type="hidden" name="scd" value="EPAYTEST">
                                <input type="hidden" name="pid" value="<?php echo $orderId; ?>">
                                <input type="hidden" name="su" value="<?php echo $_SERVER['HTTP_HOST']; ?>/payment-success.php?order_id=<?php echo $orderId; ?>">
                                <input type="hidden" name="fu" value="<?php echo $_SERVER['HTTP_HOST']; ?>/payment-failed.php?order_id=<?php echo $orderId; ?>">
                                
                                <button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg">
                                    <i class="fas fa-wallet mr-2"></i>Pay with eSewa
                                </button>
                            </form>
                        </div>
                    
                    <?php elseif ($paymentMethod === 'khalti'): ?>
                        <div class="text-center">
                            <p class="mb-4">Click the button below to pay with Khalti.</p>
                            <button id="payment-button" class="bg-purple-500 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg">
                                <i class="fas fa-mobile-alt mr-2"></i>Pay with Khalti
                            </button>
                        </div>
                        
                        <script>
                            var config = {
                                "publicKey": "test_public_key_dc74e0fd57cb46cd93832aee0a390234",
                                "productIdentity": "<?php echo $orderId; ?>",
                                "productName": "Order #<?php echo $orderId; ?>",
                                "productUrl": "<?php echo $_SERVER['HTTP_HOST']; ?>",
                                "paymentPreference": [
                                    "KHALTI",
                                    "EBANKING",
                                    "MOBILE_BANKING",
                                    "CONNECT_IPS",
                                    "SCT",
                                ],
                                "eventHandler": {
                                    onSuccess (payload) {
                                        // Hit merchant api for initiating verfication
                                        fetch('payment.php?order_id=<?php echo $orderId; ?>&method=khalti', {
                                            method: 'POST',
                                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                            body: 'token=' + payload.token
                                        }).then(() => {
                                            location.reload();
                                        });
                                    },
                                    onError (error) {
                                        console.log(error);
                                        alert('Payment failed');
                                    },
                                    onClose () {
                                        console.log('widget is closing');
                                    }
                                }
                            };
                            
                            var checkout = new KhaltiCheckout(config);
                            var btn = document.getElementById("payment-button");
                            btn.onclick = function () {
                                checkout.show({amount: <?php echo $order['final_amount'] * 100; ?>});
                            }
                        </script>
                    
                    <?php elseif ($paymentMethod === 'bank'): ?>
                        <div>
                            <h3 class="text-lg font-semibold mb-4">Bank Deposit Instructions</h3>
                            <div class="bg-blue-50 p-4 rounded-lg mb-4">
                                <p class="mb-2"><strong>Bank:</strong> Nepal Bank Limited</p>
                                <p class="mb-2"><strong>Account Name:</strong> E-commerce Store</p>
                                <p class="mb-2"><strong>Account Number:</strong> 1234567890</p>
                                <p class="mb-2"><strong>Amount:</strong> रु <?php echo number_format($order['final_amount'], 2); ?></p>
                            </div>
                            
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-4">
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        <i class="fas fa-receipt mr-2"></i>Upload Payment Receipt (JPG, PNG - Max 2MB)
                                    </label>
                                    <input type="file" name="receipt" accept=".jpg,.jpeg,.png" required 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500">
                                </div>
                                
                                <button type="submit" 
                                        class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                                    <i class="fas fa-upload mr-2"></i>Upload Receipt
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
