<?php
require_once 'includes/db.php';

$productId = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND status = 'active'");
$stmt->execute([$productId]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - E-commerce Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <i class="fas fa-store text-2xl text-blue-500 mr-3"></i>
                    <h1 class="text-2xl font-bold text-gray-800">E-commerce Store</h1>
                </div>
                
                <nav class="flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-blue-500">
                        <i class="fas fa-home mr-2"></i>Home
                    </a>
                    <a href="cart.php" class="text-gray-700 hover:text-blue-500">
                        <i class="fas fa-shopping-cart mr-2"></i>Cart
                        <span id="cart-count" class="bg-red-500 text-white rounded-full px-2 py-1 text-xs">0</span>
                    </a>
                </nav>
            </div>
        </div>
    </header>
    
    <!-- Product Details -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="md:flex">
                    <!-- Product Image -->
                    <div class="md:w-1/2">
                        <?php if ($product['image']): ?>
                            <img src="uploads/images/<?php echo $product['image']; ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 class="w-full h-96 object-cover">
                        <?php else: ?>
                            <div class="w-full h-96 bg-gray-200 flex items-center justify-center">
                                <i class="fas fa-image text-gray-400 text-6xl"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Product Info -->
                    <div class="md:w-1/2 p-8">
                        <h1 class="text-3xl font-bold text-gray-800 mb-4">
                            <?php echo htmlspecialchars($product['name']); ?>
                        </h1>
                        
                        <div class="text-3xl font-bold text-blue-500 mb-6">
                            रु <?php echo number_format($product['price'], 2); ?>
                        </div>
                        
                        <div class="mb-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-2">Description</h3>
                            <p class="text-gray-600 leading-relaxed">
                                <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                            </p>
                        </div>
                        
                        <div class="flex space-x-4 mb-6">
                            <button onclick="addToCart(<?php echo $product['id']; ?>)" 
                                    class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300">
                                <i class="fas fa-cart-plus mr-2"></i>Add to Cart
                            </button>
                            <a href="index.php" 
                               class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300">
                                <i class="fas fa-arrow-left mr-2"></i>Back to Store
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Product Video -->
                <?php if ($product['video']): ?>
                <div class="p-8 border-t">
                    <h3 class="text-xl font-semibold text-gray-800 mb-4">Product Video</h3>
                    <video controls class="w-full max-w-2xl mx-auto rounded-lg">
                        <source src="uploads/videos/<?php echo $product['video']; ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    
    <script>
        // Simple cart functionality
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        updateCartCount();
        
        function addToCart(productId) {
            const existingItem = cart.find(item => item.id === productId);
            
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({ id: productId, quantity: 1 });
            }
            
            localStorage.setItem('cart', JSON.stringify(cart));
            updateCartCount();
            
            // Show success message
            alert('Product added to cart!');
        }
        
        function updateCartCount() {
            const count = cart.reduce((total, item) => total + item.quantity, 0);
            document.getElementById('cart-count').textContent = count;
        }
    </script>
</body>
</html>
