<?php
require_once 'includes/db.php';

// Get all active products
$stmt = $pdo->query("SELECT * FROM products WHERE status = 'active' ORDER BY created_at DESC");
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-commerce Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <i class="fas fa-store text-2xl text-blue-500 mr-3"></i>
                    <h1 class="text-2xl font-bold text-gray-800">E-commerce Store</h1>
                </div>
                
                <nav class="flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-blue-500">
                        <i class="fas fa-home mr-2"></i>Home
                    </a>
                    <a href="cart.php" class="text-gray-700 hover:text-blue-500">
                        <i class="fas fa-shopping-cart mr-2"></i>Cart
                        <span id="cart-count" class="bg-red-500 text-white rounded-full px-2 py-1 text-xs">0</span>
                    </a>
                    <a href="login.php" class="text-gray-700 hover:text-blue-500">
                        <i class="fas fa-user mr-2"></i>Admin
                    </a>
                </nav>
            </div>
        </div>
    </header>
    
    <!-- Hero Section -->
    <section class="bg-blue-500 text-white py-16">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold mb-4">Welcome to Our Store</h2>
            <p class="text-xl mb-8">Discover amazing products at great prices</p>
            <a href="#products" class="bg-white text-blue-500 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-300">
                Shop Now
            </a>
        </div>
    </section>
    
    <!-- Products Section -->
    <section id="products" class="py-16">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12 text-gray-800">Our Products</h2>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php foreach ($products as $product): ?>
                <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition duration-300">
                    <div class="relative">
                        <?php if ($product['image']): ?>
                            <img src="uploads/images/<?php echo $product['image']; ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 class="w-full h-48 object-cover">
                        <?php else: ?>
                            <div class="w-full h-48 bg-gray-200 flex items-center justify-center">
                                <i class="fas fa-image text-gray-400 text-4xl"></i>
                            </div>
                        <?php endif; ?>
                        
                        <div class="absolute top-2 right-2">
                            <span class="bg-blue-500 text-white px-2 py-1 rounded text-sm font-semibold">
                                रु <?php echo number_format($product['price'], 2); ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="p-4">
                        <h3 class="text-lg font-semibold text-gray-800 mb-2">
                            <?php echo htmlspecialchars($product['name']); ?>
                        </h3>
                        
                        <p class="text-gray-600 text-sm mb-4 line-clamp-2">
                            <?php echo htmlspecialchars(substr($product['description'], 0, 100)) . '...'; ?>
                        </p>
                        
                        <div class="flex space-x-2">
                            <button onclick="addToCart(<?php echo $product['id']; ?>)" 
                                    class="flex-1 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-300">
                                <i class="fas fa-cart-plus mr-2"></i>Buy
                            </button>
                            <a href="product.php?id=<?php echo $product['id']; ?>" 
                               class="flex-1 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded text-center transition duration-300">
                                <i class="fas fa-eye mr-2"></i>View
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php if (empty($products)): ?>
                <div class="text-center py-16">
                    <i class="fas fa-box-open text-6xl text-gray-400 mb-4"></i>
                    <h3 class="text-xl font-semibold text-gray-600 mb-2">No Products Available</h3>
                    <p class="text-gray-500">Check back later for new products!</p>
                </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-8">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; 2024 E-commerce Store. All rights reserved.</p>
        </div>
    </footer>
    
    <script>
        // Simple cart functionality
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        updateCartCount();
        
        function addToCart(productId) {
            const existingItem = cart.find(item => item.id === productId);
            
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({ id: productId, quantity: 1 });
            }
            
            localStorage.setItem('cart', JSON.stringify(cart));
            updateCartCount();
            
            // Show success message
            alert('Product added to cart!');
        }
        
        function updateCartCount() {
            const count = cart.reduce((total, item) => total + item.quantity, 0);
            document.getElementById('cart-count').textContent = count;
        }
    </script>
</body>
</html>
