<?php
require_once '../includes/auth.php';
requireAdminLogin();

// Get statistics
$stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users");
$totalUsers = $stmt->fetch()['total_users'];

$stmt = $pdo->query("SELECT COUNT(*) as total_orders FROM orders");
$totalOrders = $stmt->fetch()['total_orders'];

$stmt = $pdo->query("SELECT COUNT(*) as total_products FROM products WHERE status = 'active'");
$totalProducts = $stmt->fetch()['total_products'];

$stmt = $pdo->query("SELECT SUM(final_amount) as total_revenue FROM orders WHERE payment_status = 'completed'");
$totalRevenue = $stmt->fetch()['total_revenue'] ?? 0;

// Recent orders
$stmt = $pdo->query("SELECT o.*, u.name as user_name FROM orders o 
                     LEFT JOIN users u ON o.user_id = u.id 
                     ORDER BY o.created_at DESC LIMIT 5");
$recentOrders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-64 min-h-screen p-4">
            <div class="mb-8">
                <h1 class="text-xl font-bold">
                    <i class="fas fa-store mr-2"></i>E-commerce Admin
                </h1>
            </div>
            
            <nav class="space-y-2">
                <a href="dashboard.php" class="flex items-center p-2 bg-gray-700 rounded">
                    <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
                </a>
                <a href="add-product.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-plus mr-3"></i>Add Product
                </a>
                <a href="manage-products.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-box mr-3"></i>Manage Products
                </a>
                <a href="manage-orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-shopping-cart mr-3"></i>Manage Orders
                </a>
                <a href="promo-codes.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-tags mr-3"></i>Promo Codes
                </a>
                <a href="plans.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-crown mr-3"></i>Plans
                </a>
                <a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded text-red-300">
                    <i class="fas fa-sign-out-alt mr-3"></i>Logout
                </a>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 p-8">
            <div class="mb-8">
                <h2 class="text-3xl font-bold text-gray-800">Dashboard</h2>
                <p class="text-gray-600">Welcome back, <?php echo $_SESSION['admin_username']; ?>!</p>
            </div>
            
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="flex items-center">
                        <div class="p-3 bg-blue-100 rounded-full">
                            <i class="fas fa-users text-blue-500 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-semibold text-gray-800"><?php echo $totalUsers; ?></h3>
                            <p class="text-gray-600">Total Users</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="flex items-center">
                        <div class="p-3 bg-green-100 rounded-full">
                            <i class="fas fa-shopping-cart text-green-500 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-semibold text-gray-800"><?php echo $totalOrders; ?></h3>
                            <p class="text-gray-600">Total Orders</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="flex items-center">
                        <div class="p-3 bg-purple-100 rounded-full">
                            <i class="fas fa-box text-purple-500 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-semibold text-gray-800"><?php echo $totalProducts; ?></h3>
                            <p class="text-gray-600">Active Products</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <div class="flex items-center">
                        <div class="p-3 bg-yellow-100 rounded-full">
                            <i class="fas fa-rupee-sign text-yellow-500 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-lg font-semibold text-gray-800">रु <?php echo number_format($totalRevenue, 2); ?></h3>
                            <p class="text-gray-600">Total Revenue</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Orders -->
            <div class="bg-white rounded-lg shadow-md">
                <div class="p-6 border-b">
                    <h3 class="text-xl font-semibold text-gray-800">Recent Orders</h3>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php foreach ($recentOrders as $order): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                    #<?php echo $order['id']; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo $order['customer_name'] ?? $order['user_name'] ?? 'Guest'; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    रु <?php echo number_format($order['final_amount'], 2); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                        <?php echo $order['order_status'] === 'complete' ? 'bg-green-100 text-green-800' : 
                                                  ($order['order_status'] === 'shipped' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                        <?php echo ucfirst($order['order_status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo date('M d, Y', strtotime($order['created_at'])); ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
