<?php
require_once '../includes/auth.php';
require_once '../includes/payment-functions.php';
requireAdminLogin();

$message = '';
$error = '';

if ($_POST) {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $price = $_POST['price'] ?? 0;
    
    $imageName = '';
    $videoName = '';
    
    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $imageName = uploadFile($_FILES['image'], '../uploads/images', ['jpg', 'jpeg', 'png'], 2 * 1024 * 1024);
        if (!$imageName) {
            $error = 'Invalid image file. Only JPG, PNG allowed (max 2MB)';
        }
    }
    
    // Handle video upload
    if (isset($_FILES['video']) && $_FILES['video']['error'] === UPLOAD_ERR_OK) {
        $videoName = uploadFile($_FILES['video'], '../uploads/videos', ['mp4'], 20 * 1024 * 1024);
        if (!$videoName) {
            $error = 'Invalid video file. Only MP4 allowed (max 20MB)';
        }
    }
    
    if (!$error) {
        try {
            $stmt = $pdo->prepare("INSERT INTO products (name, description, price, image, video) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $description, $price, $imageName, $videoName]);
            $message = 'Product added successfully!';
        } catch(PDOException $e) {
            $error = 'Error adding product: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-64 min-h-screen p-4">
            <div class="mb-8">
                <h1 class="text-xl font-bold">
                    <i class="fas fa-store mr-2"></i>E-commerce Admin
                </h1>
            </div>
            
            <nav class="space-y-2">
                <a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
                </a>
                <a href="add-product.php" class="flex items-center p-2 bg-gray-700 rounded">
                    <i class="fas fa-plus mr-3"></i>Add Product
                </a>
                <a href="manage-products.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-box mr-3"></i>Manage Products
                </a>
                <a href="manage-orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-shopping-cart mr-3"></i>Manage Orders
                </a>
                <a href="promo-codes.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-tags mr-3"></i>Promo Codes
                </a>
                <a href="plans.php" class="flex items-center p-2 hover:bg-gray-700 rounded">
                    <i class="fas fa-crown mr-3"></i>Plans
                </a>
                <a href="logout.php" class="flex items-center p-2 hover:bg-gray-700 rounded text-red-300">
                    <i class="fas fa-sign-out-alt mr-3"></i>Logout
                </a>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 p-8">
            <div class="mb-8">
                <h2 class="text-3xl font-bold text-gray-800">Add New Product</h2>
            </div>
            
            <?php if ($message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="bg-white rounded-lg shadow-md p-6">
                <form method="POST" enctype="multipart/form-data" class="space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-tag mr-2"></i>Product Name
                        </label>
                        <input type="text" name="name" required 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-align-left mr-2"></i>Description
                        </label>
                        <textarea name="description" rows="4" 
                                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500"></textarea>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-rupee-sign mr-2"></i>Price (NPR)
                        </label>
                        <input type="number" name="price" step="0.01" required 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-image mr-2"></i>Product Image (JPG, PNG - Max 2MB)
                        </label>
                        <input type="file" name="image" accept=".jpg,.jpeg,.png" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-video mr-2"></i>Product Video (MP4 - Max 20MB)
                        </label>
                        <input type="file" name="video" accept=".mp4" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500">
                    </div>
                    
                    <div class="flex space-x-4">
                        <button type="submit" 
                                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md transition duration-300">
                            <i class="fas fa-plus mr-2"></i>Add Product
                        </button>
                        <a href="manage-products.php" 
                           class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-md transition duration-300">
                            <i class="fas fa-list mr-2"></i>View All Products
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
