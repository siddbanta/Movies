<?php
require_once 'includes/db.php';
require_once 'includes/payment-functions.php';

// Get cart items from localStorage via JavaScript
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - E-commerce Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <i class="fas fa-store text-2xl text-blue-500 mr-3"></i>
                    <h1 class="text-2xl font-bold text-gray-800">E-commerce Store</h1>
                </div>
                
                <nav class="flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-blue-500">
                        <i class="fas fa-home mr-2"></i>Home
                    </a>
                    <a href="cart.php" class="text-blue-500 font-semibold">
                        <i class="fas fa-shopping-cart mr-2"></i>Cart
                    </a>
                </nav>
            </div>
        </div>
    </header>
    
    <!-- Cart Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12 text-gray-800">Shopping Cart</h2>
            
            <div class="max-w-4xl mx-auto">
                <div id="cart-items" class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <!-- Cart items will be loaded here -->
                </div>
                
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-tag mr-2"></i>Promo Code
                        </label>
                        <div class="flex">
                            <input type="text" id="promo-code" placeholder="Enter promo code (try: 123)" 
                                   class="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:border-blue-500">
                            <button onclick="applyPromo()" 
                                    class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded-r-md transition duration-300">
                                Apply
                            </button>
                        </div>
                    </div>
                    
                    <div class="border-t pt-4">
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-lg">Subtotal:</span>
                            <span id="subtotal" class="text-lg font-semibold">रु 0.00</span>
                        </div>
                        <div class="flex justify-between items-center mb-2" id="discount-row" style="display: none;">
                            <span class="text-lg text-green-600">Discount:</span>
                            <span id="discount" class="text-lg font-semibold text-green-600">-रु 0.00</span>
                        </div>
                        <div class="flex justify-between items-center mb-4 text-xl font-bold">
                            <span>Total:</span>
                            <span id="total" class="text-blue-500">रु 0.00</span>
                        </div>
                        
                        <button onclick="proceedToCheckout()" 
                                class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                            <i class="fas fa-credit-card mr-2"></i>Proceed to Checkout
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <script>
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let products = [];
        let appliedPromo = null;
        
        // Load cart items
        async function loadCartItems() {
            if (cart.length === 0) {
                document.getElementById('cart-items').innerHTML = `
                    <div class="text-center py-8">
                        <i class="fas fa-shopping-cart text-6xl text-gray-400 mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-600 mb-2">Your cart is empty</h3>
                        <a href="index.php" class="text-blue-500 hover:text-blue-700">Continue Shopping</a>
                    </div>
                `;
                return;
            }
            
            // Fetch product details
            const productIds = cart.map(item => item.id);
            const response = await fetch('api/get-products.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ids: productIds })
            });
            
            products = await response.json();
            renderCartItems();
            calculateTotal();
        }
        
        function renderCartItems() {
            const cartItemsHtml = cart.map(cartItem => {
                const product = products.find(p => p.id == cartItem.id);
                if (!product) return '';
                
                return `
                    <div class="flex items-center border-b pb-4 mb-4">
                        <img src="uploads/images/${product.image || 'placeholder.jpg'}" 
                             alt="${product.name}" class="w-16 h-16 object-cover rounded">
                        <div class="flex-1 ml-4">
                            <h3 class="font-semibold">${product.name}</h3>
                            <p class="text-gray-600">रु ${parseFloat(product.price).toFixed(2)}</p>
                        </div>
                        <div class="flex items-center space-x-2">
                            <button onclick="updateQuantity(${product.id}, -1)" 
                                    class="bg-gray-200 hover:bg-gray-300 px-2 py-1 rounded">-</button>
                            <span class="px-3">${cartItem.quantity}</span>
                            <button onclick="updateQuantity(${product.id}, 1)" 
                                    class="bg-gray-200 hover:bg-gray-300 px-2 py-1 rounded">+</button>
                        </div>
                        <div class="ml-4">
                            <span class="font-semibold">रु ${(parseFloat(product.price) * cartItem.quantity).toFixed(2)}</span>
                        </div>
                        <button onclick="removeFromCart(${product.id})" 
                                class="ml-4 text-red-500 hover:text-red-700">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                `;
            }).join('');
            
            document.getElementById('cart-items').innerHTML = cartItemsHtml;
        }
        
        function updateQuantity(productId, change) {
            const item = cart.find(item => item.id === productId);
            if (item) {
                item.quantity += change;
                if (item.quantity <= 0) {
                    removeFromCart(productId);
                } else {
                    localStorage.setItem('cart', JSON.stringify(cart));
                    renderCartItems();
                    calculateTotal();
                }
            }
        }
        
        function removeFromCart(productId) {
            cart = cart.filter(item => item.id !== productId);
            localStorage.setItem('cart', JSON.stringify(cart));
            loadCartItems();
        }
        
        function calculateTotal() {
            const subtotal = cart.reduce((total, cartItem) => {
                const product = products.find(p => p.id == cartItem.id);
                return total + (product ? parseFloat(product.price) * cartItem.quantity : 0);
            }, 0);
            
            let discount = 0;
            if (appliedPromo) {
                discount = (subtotal * appliedPromo.discount_percent) / 100;
            }
            
            const total = subtotal - discount;
            
            document.getElementById('subtotal').textContent = `रु ${subtotal.toFixed(2)}`;
            document.getElementById('discount').textContent = `-रु ${discount.toFixed(2)}`;
            document.getElementById('total').textContent = `रु ${total.toFixed(2)}`;
            
            if (discount > 0) {
                document.getElementById('discount-row').style.display = 'flex';
            } else {
                document.getElementById('discount-row').style.display = 'none';
            }
        }
        
        async function applyPromo() {
            const promoCode = document.getElementById('promo-code').value;
            
            const response = await fetch('api/validate-promo.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code: promoCode })
            });
            
            const result = await response.json();
            
            if (result.valid) {
                appliedPromo = result;
                calculateTotal();
                alert(`Promo code applied! ${result.discount_percent}% discount`);
            } else {
                alert('Invalid promo code');
            }
        }
        
        function proceedToCheckout() {
            if (cart.length === 0) {
                alert('Your cart is empty');
                return;
            }
            
            localStorage.setItem('checkout_data', JSON.stringify({
                cart: cart,
                products: products,
                promo: appliedPromo
            }));
            
            window.location.href = 'checkout.php';
        }
        
        // Load cart items on page load
        loadCartItems();
    </script>
</body>
</html>
