<?php
require_once 'includes/db.php';
require_once 'includes/payment-functions.php';

$message = '';
$error = '';

if ($_POST) {
    $customerName = $_POST['customer_name'] ?? '';
    $customerPhone = $_POST['customer_phone'] ?? '';
    $deliveryAddress = $_POST['delivery_address'] ?? '';
    $paymentMethod = $_POST['payment_method'] ?? '';
    
    // Get checkout data from session or form
    $checkoutData = json_decode($_POST['checkout_data'] ?? '{}', true);
    
    if (empty($checkoutData)) {
        $error = 'Invalid checkout data';
    } else {
        $cart = $checkoutData['cart'];
        $products = $checkoutData['products'];
        $promo = $checkoutData['promo'];
        
        // Calculate totals
        $subtotal = 0;
        foreach ($cart as $cartItem) {
            $product = array_filter($products, fn($p) => $p['id'] == $cartItem['id'])[0] ?? null;
            if ($product) {
                $subtotal += $product['price'] * $cartItem['quantity'];
            }
        }
        
        $discountAmount = 0;
        $promoCode = '';
        if ($promo) {
            $discountAmount = ($subtotal * $promo['discount_percent']) / 100;
            $promoCode = $promo['code'];
        }
        
        $finalAmount = $subtotal - $discountAmount;
        
        try {
            $pdo->beginTransaction();
            
            // Create order
            $stmt = $pdo->prepare("INSERT INTO orders (total_amount, discount_amount, final_amount, promo_code, payment_method, delivery_address, customer_name, customer_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$subtotal, $discountAmount, $finalAmount, $promoCode, $paymentMethod, $deliveryAddress, $customerName, $customerPhone]);
            
            $orderId = $pdo->lastInsertId();
            
            // Add order items
            foreach ($cart as $cartItem) {
                $product = array_filter($products, fn($p) => $p['id'] == $cartItem['id'])[0] ?? null;
                if ($product) {
                    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$orderId, $product['id'], $cartItem['quantity'], $product['price']]);
                }
            }
            
            $pdo->commit();
            
            // Redirect to payment
            header("Location: payment.php?order_id=$orderId&method=$paymentMethod");
            exit();
            
        } catch(PDOException $e) {
            $pdo->rollBack();
            $error = 'Error creating order: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - E-commerce Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <!-- Header -->
    <header class="bg-white shadow-md">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center">
                    <i class="fas fa-store text-2xl text-blue-500 mr-3"></i>
                    <h1 class="text-2xl font-bold text-gray-800">E-commerce Store</h1>
                </div>
                
                <nav class="flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-blue-500">
                        <i class="fas fa-home mr-2"></i>Home
                    </a>
                    <a href="cart.php" class="text-gray-700 hover:text-blue-500">
                        <i class="fas fa-shopping-cart mr-2"></i>Cart
                    </a>
                </nav>
            </div>
        </div>
    </header>
    
    <!-- Checkout Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12 text-gray-800">Checkout</h2>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 max-w-2xl mx-auto">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="max-w-2xl mx-auto">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <form method="POST" id="checkout-form">
                        <input type="hidden" name="checkout_data" id="checkout_data">
                        
                        <div class="mb-6">
                            <h3 class="text-xl font-semibold mb-4">Delivery Information</h3>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-user mr-2"></i>Full Name
                                </label>
                                <input type="text" name="customer_name" required 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500">
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-phone mr-2"></i>Phone Number
                                </label>
                                <input type="tel" name="customer_phone" required 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500">
                            </div>
                            
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-map-marker-alt mr-2"></i>Delivery Address
                                </label>
                                <textarea name="delivery_address" rows="3" required 
                                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:border-blue-500"></textarea>
                            </div>
                        </div>
                        
                        <div class="mb-6">
                            <h3 class="text-xl font-semibold mb-4">Payment Method</h3>
                            
                            <div class="space-y-3">
                                <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                                    <input type="radio" name="payment_method" value="esewa" class="mr-3">
                                    <i class="fas fa-wallet text-green-500 mr-3"></i>
                                    <span>eSewa</span>
                                </label>
                                
                                <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                                    <input type="radio" name="payment_method" value="khalti" class="mr-3">
                                    <i class="fas fa-mobile-alt text-purple-500 mr-3"></i>
                                    <span>Khalti</span>
                                </label>
                                
                                <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                                    <input type="radio" name="payment_method" value="bank" class="mr-3">
                                    <i class="fas fa-university text-blue-500 mr-3"></i>
                                    <span>Bank Deposit</span>
                                </label>
                            </div>
                        </div>
                        
                        <div class="mb-6" id="order-summary">
                            <h3 class="text-xl font-semibold mb-4">Order Summary</h3>
                            <div id="summary-items"></div>
                        </div>
                        
                        <button type="submit" 
                                class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                            <i class="fas fa-credit-card mr-2"></i>Place Order
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    
    <script>
        // Load checkout data
        const checkoutData = JSON.parse(localStorage.getItem('checkout_data') || '{}');
        
        if (Object.keys(checkoutData).length === 0) {
            alert('No checkout data found. Redirecting to cart.');
            window.location.href = 'cart.php';
        }
        
        // Set checkout data in form
        document.getElementById('checkout_data').value = JSON.stringify(checkoutData);
        
        // Display order summary
        function displayOrderSummary() {
            const { cart, products, promo } = checkoutData;
            
            let subtotal = 0;
            let summaryHtml = '';
            
            cart.forEach(cartItem => {
                const product = products.find(p => p.id == cartItem.id);
                if (product) {
                    const itemTotal = product.price * cartItem.quantity;
                    subtotal += itemTotal;
                    
                    summaryHtml += `
                        <div class="flex justify-between items-center py-2 border-b">
                            <span>${product.name} x ${cartItem.quantity}</span>
                            <span>रु ${itemTotal.toFixed(2)}</span>
                        </div>
                    `;
                }
            });
            
            let discount = 0;
            if (promo) {
                discount = (subtotal * promo.discount_percent) / 100;
                summaryHtml += `
                    <div class="flex justify-between items-center py-2 text-green-600">
                        <span>Discount (${promo.code})</span>
                        <span>-रु ${discount.toFixed(2)}</span>
                    </div>
                `;
            }
            
            const total = subtotal - discount;
            summaryHtml += `
                <div class="flex justify-between items-center py-2 font-bold text-lg">
                    <span>Total</span>
                    <span class="text-blue-500">रु ${total.toFixed(2)}</span>
                </div>
            `;
            
            document.getElementById('summary-items').innerHTML = summaryHtml;
        }
        
        displayOrderSummary();
    </script>
</body>
</html>
