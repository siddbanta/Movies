<?php
require_once 'db.php';

function validatePromoCode($code) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT discount_percent FROM promos WHERE code = ? AND status = 'active'");
    $stmt->execute([$code]);
    $promo = $stmt->fetch();
    
    return $promo ? $promo['discount_percent'] : false;
}

function calculateDiscount($total, $promoCode) {
    $discount = validatePromoCode($promoCode);
    if ($discount !== false) {
        return ($total * $discount) / 100;
    }
    return 0;
}

function verifyEsewaPayment($refId, $amount) {
    // eSewa verification logic
    $url = "https://uat.esewa.com.np/epay/transrec";
    
    $data = [
        'amt' => $amount,
        'rid' => $refId,
        'pid' => 'your_product_id',
        'scd' => 'your_merchant_code'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return strpos($response, 'Success') !== false;
}

function verifyKhaltiPayment($token, $amount) {
    $url = "https://khalti.com/api/v2/payment/verify/";
    
    $data = [
        'token' => $token,
        'amount' => $amount * 100 // Khalti uses paisa
    ];
    
    $headers = [
        'Authorization: Key your_khalti_secret_key',
        'Content-Type: application/json'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    return isset($result['state']['name']) && $result['state']['name'] === 'Completed';
}

function uploadFile($file, $uploadDir, $allowedTypes, $maxSize) {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    $fileType = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($fileType, $allowedTypes)) {
        return false;
    }
    
    if ($file['size'] > $maxSize) {
        return false;
    }
    
    $fileName = uniqid() . '.' . $fileType;
    $uploadPath = $uploadDir . '/' . $fileName;
    
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        return $fileName;
    }
    
    return false;
}
?>
